import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Pin · 地图壁纸工作室',
  description: '搜索任意地点，自定义配色，导出专属的 4K 地图壁纸。',
  openGraph: {
    title: 'PIN · Map Wallpaper Studio',
    description: '搜索任意地点，制作属于你的 4K 地图壁纸。',
    images: ['/og.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PIN · Map Wallpaper Studio',
    description: '搜索任意地点，制作属于你的 4K 地图壁纸。',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
